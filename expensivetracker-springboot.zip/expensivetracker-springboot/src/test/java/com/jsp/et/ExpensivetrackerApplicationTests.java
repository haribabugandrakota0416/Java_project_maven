package com.jsp.et;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpensivetrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
