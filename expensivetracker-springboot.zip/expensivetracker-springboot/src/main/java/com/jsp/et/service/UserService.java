package com.jsp.et.service;

import com.jsp.et.dto.UserDTO;

public interface UserService {
	int registration(UserDTO dto);

	UserDTO login(UserDTO dto);
	
	public UserDTO findByUserId(int userid);
	
	public UserDTO updateUserProfile(int userid,UserDTO dto);
	
	public int deletUserProfile(int userid);
	
}
