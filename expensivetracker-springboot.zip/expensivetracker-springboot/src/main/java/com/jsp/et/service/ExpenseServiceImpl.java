package com.jsp.et.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.et.dto.ExpensiveDTO;
import com.jsp.et.entity.Expensive;
import com.jsp.et.entity.ExpensiveCategery;
import com.jsp.et.entity.User;
import com.jsp.et.repositry.ExpensiveCategoryRepositry;
import com.jsp.et.repositry.ExpensiveRepositry;
import com.jsp.et.repositry.UserRepostry;

@Service
public class ExpenseServiceImpl implements ExpensiveService {

	@Autowired
	private ExpensiveRepositry expensiveRepositry;

	@Autowired
	private ExpensiveCategoryRepositry categoryRepositry;

	@Autowired
	private UserRepostry userRepostry;

	/*
	 * Expen
	 */

	@Override
	public int addExpense(ExpensiveDTO dto, int userid) {
		Optional<ExpensiveCategery> category = categoryRepositry.findByCategery(dto.getCategery());
		Optional<User> user = userRepostry.findById(userid);

		if (category.isPresent()) {
			Expensive expensive = new Expensive();

			expensive.setDate(LocalDate.parse(dto.getDate()));
			BeanUtils.copyProperties(dto, expensive);
			expensive.setExpensiveCategery(category.get());
			expensive.setUser(user.get());

			return expensiveRepositry.save(expensive).getExpensiveid();
		}

		return 0;
	}

	@Override
	public List<ExpensiveDTO> viewExpense(int userid) {

		User user = userRepostry.findById(userid).get();

		return expensiveRepositry.findByUser(user).stream().map(t -> {
			ExpensiveDTO dto = new ExpensiveDTO();
			BeanUtils.copyProperties(t, dto);
			dto.setCategery(t.getExpensiveCategery().getCategery());
			// CONVERT LOCAL DATE OF ENTITY CLASS INTO STRING OF DTO
			dto.setDate(t.getDate().toString());
			return dto;
		}).collect(Collectors.toList());

	}

	@Override
	public ExpensiveDTO updateExpense(ExpensiveDTO dto, int expensiveid) {
		Expensive expensive = expensiveRepositry.findById(expensiveid).get();
		if (expensive != null) {
			expensive.setAmount(dto.getAmount());
			expensive.setDate(LocalDate.parse(dto.getDate()));
			expensive.setDescription(dto.getDescription());
			ExpensiveCategery expensiveCategery = categoryRepositry.findByCategery(dto.getCategery()).get();
			expensive.setExpensiveCategery(expensiveCategery);
			ExpensiveDTO updated = new ExpensiveDTO();
			BeanUtils.copyProperties(expensiveRepositry.save(expensive), updated);
			return updated;
		}
		return null;
	}

	@Override
	public int deletExpense(int expensiveid) {
		Optional<Expensive> expensedb = expensiveRepositry.findById(expensiveid);
		if (expensedb.isPresent()) {
			expensiveRepositry.delete(expensedb.get());
			return 1;
		}
		return 0;
	}

	@Override
	public ExpensiveDTO findByExpensiveid(int expensiveid) {
		Optional<Expensive> expensivedb = expensiveRepositry.findById(expensiveid);
		if (expensivedb.isPresent()) {
			ExpensiveDTO dto = new ExpensiveDTO();
			Expensive expenses = expensivedb.get();
			BeanUtils.copyProperties(expenses, dto);
			dto.setDate(expenses.getDate().toString());
			dto.setCategery(expensivedb.get().getExpensiveCategery().getCategery());
			return dto;
		}
		return null;
	}

	@Override
	public List<ExpensiveDTO> filterBasedOnDateCategeryAmount(ExpensiveDTO dto, int userid) {
		// TODO Auto-generated method stub
		return viewExpense(userid).stream().filter(t -> t.getDate().equals(dto.getDate())
				&& t.getAmount() == dto.getAmount() && t.getCategery().equals(dto.getCategery()))
				.collect(Collectors.toList());
	}

	@Override
	public List<ExpensiveDTO> filterBasedOnDate(ExpensiveDTO dto, int userid) {
		return viewExpense(userid).stream().filter(t -> t.getDate().equals(dto.getDate())).collect(Collectors.toList());
	}

	@Override
	public List<ExpensiveDTO> filterBasedOnAmount(int userid, String amount) {
		String[] amoun = amount.split("-");
		int firstValue = Integer.parseInt(amoun[0]);
		int secondValue = Integer.parseInt(amoun[1]);
		return viewExpense(userid).stream().filter(t -> t.getAmount() >= firstValue && t.getAmount() <= secondValue)
				.collect(Collectors.toList());
	}

	@Override
	public List<ExpensiveDTO> filterBasedOnCategery(ExpensiveDTO dto, int userid) {

		return viewExpense(userid).stream().filter(t ->t.getCategery().equals(dto.getCategery()))
				.collect(Collectors.toList());
	}

	@Override
	public List<ExpensiveDTO> filterBasedOnCategeryAmount(ExpensiveDTO dto, int userid, String amount) {
		String[] amoun = amount.split("-");
		int firstValue = Integer.parseInt(amoun[0]);
		int secondValue = Integer.parseInt(amoun[1]);
		return viewExpense(userid).stream().filter(t -> t.getCategery().equals(dto.getCategery())
				&& t.getAmount() >= firstValue && t.getAmount() <= secondValue).collect(Collectors.toList());
	}

	/*it find total of expenses between given date from respective user*/
	@Override
	public List<ExpensiveDTO> filterExpensesBasedOnDate(LocalDate start, LocalDate end,int userid) {
		/*
		 * 1.get all expenses for respective user 2.make use of stream api to filter 
		 * expenses based on given strat and end date 
		 */
		
		return viewExpense(userid)
				.stream()
				.filter(t->{LocalDate date=LocalDate.parse(t.getDate());
				return !date.isBefore(start)&&!date.isAfter(end);}).collect(Collectors.toList());
		}
}
