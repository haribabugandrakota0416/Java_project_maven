package com.jsp.et.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ExpensiveDTO {
	
	private int expensiveid;
	
	
	private String date;
	private double amount;
	private String description;
	//to take range of amount select by user
	private String range;
	//creating expensecategorydto rv may diffuculties in service layer hence go with string 
	private String categery;
}

