package com.jsp.et.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jsp.et.dto.ExpensiveDTO;
import com.jsp.et.service.ExpensiveService;

@Controller
@RequestMapping("/expense")
public class AppControler {
	
	@RequestMapping("/index")
	public String index()
	{
		return "index";
	}
	@RequestMapping("/home")
	public String home()
	{
		return "Home";
	}
	@RequestMapping("/login")
	public String login(@ModelAttribute("msg") String message)
	{
		return "login";
	}
	@RequestMapping("/registration")
	public String registration(@ModelAttribute("msg") String message)
	{
		return "registration";
	}
	@RequestMapping("/addexpenses")
	public String addExpenses(@ModelAttribute("error") String message)
	{
		return "addexpenses";
	}
	
	@Autowired
	private ExpensiveService service;
	
	@RequestMapping("/updateExpenses/{id}")
	public String updateExpense(@PathVariable("id") int id,Model m)
	{
		ExpensiveDTO dto = service.findByExpensiveid(id);
		m.addAttribute("expense",dto);
		return "UpdateExpense";
	}
	
	
	
	@RequestMapping("/filterexpenses")
	public String filterExpenses()
	{
		return "filterexpenses";
	}
	
	@RequestMapping("/totalExpenses")
	public String totalExpenses()
	{
		return "totalexpenses";
	}
	
	@RequestMapping("/viewexpensess")
	public String viewExpenses(@ModelAttribute("listOfExpenses") List<ExpensiveDTO> expenses)
	{
		return "viewexpenses";
	}
}
