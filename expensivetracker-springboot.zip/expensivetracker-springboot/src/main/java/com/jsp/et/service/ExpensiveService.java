package com.jsp.et.service;

import java.time.LocalDate;
import java.util.List;

import com.jsp.et.dto.ExpensiveDTO;

public interface ExpensiveService {
	int addExpense(ExpensiveDTO dto, int userid);

	List<ExpensiveDTO> viewExpense(int userid);

	ExpensiveDTO findByExpensiveid(int expensiveid);

	ExpensiveDTO updateExpense(ExpensiveDTO dto, int expensiveid);

	int deletExpense(int expensiveid);

	List<ExpensiveDTO> filterBasedOnDateCategeryAmount(ExpensiveDTO dto, int userid);

	List<ExpensiveDTO> filterBasedOnDate(ExpensiveDTO dto, int userid);

	List<ExpensiveDTO> filterBasedOnAmount(int userid, String amount);

	List<ExpensiveDTO> filterBasedOnCategery(ExpensiveDTO dto,int userid);

	List<ExpensiveDTO> filterBasedOnCategeryAmount(ExpensiveDTO dto,int userid, String amount);

	List<ExpensiveDTO> filterExpensesBasedOnDate(LocalDate start, LocalDate end,int userid);
	
}
