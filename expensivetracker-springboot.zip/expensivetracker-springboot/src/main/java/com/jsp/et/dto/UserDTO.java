package com.jsp.et.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
//Data transfer object:-it will transfer data from controller to service
//It is usefull to store data which entered by user in frontend files
public class UserDTO {
	
	private int userid; 
	private String fullName;
	private String userName;
	private String email;
	private String mobile;
	private String password;
	private String repassword;
}
